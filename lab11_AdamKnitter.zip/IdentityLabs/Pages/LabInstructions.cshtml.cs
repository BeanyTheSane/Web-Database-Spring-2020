using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IdentityLabs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IdentityLabs.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
